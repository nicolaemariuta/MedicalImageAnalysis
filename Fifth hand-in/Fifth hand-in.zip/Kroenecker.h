#pragma once
#include <vector>
using namespace std;

template<typename T> class Kroenecker{

public:
	
	inline vector<T> kron(vector<T> a,vector<T>b){
// 	vector<T> c=vector(a.size()*b.size());
// 		for(int i=0;i<a.size();i++){
// 			for(int j=0;j<b.size();j++){
// 				c.pushback(a[i]*b[j]);
// 			}	
// 		}
		return 0;
	}

}; 

